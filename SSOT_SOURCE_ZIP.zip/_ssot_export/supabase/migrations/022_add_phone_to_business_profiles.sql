ALTER TABLE business_profiles ADD COLUMN phone text;
