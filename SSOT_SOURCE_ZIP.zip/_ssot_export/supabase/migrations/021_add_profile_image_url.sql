ALTER TABLE business_profiles ADD COLUMN IF NOT EXISTS profile_image_url TEXT;
